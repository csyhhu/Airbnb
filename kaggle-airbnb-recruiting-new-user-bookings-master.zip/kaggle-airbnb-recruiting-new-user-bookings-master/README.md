# kaggle-airbnb-recruiting-new-user-bookings

2nd place solution for Airbnb New User Bookings Competition.

Note: This code should be differ from my submitted solution(Public:0.88209/Private:0.88682) because of the seed settings. if you select a model of more than 5 fold-CV 0.833600, you can get about 0.88682(Private).

### My Approach & Program Details.
Please see [Airbnb New User Bookings, Winner’s Interview: 2nd place, Keiichi Kuroyanagi (@Keiku) | no free hunch](http://blog.kaggle.com/2016/03/17/airbnb-new-user-bookings-winners-interview-2nd-place-keiichi-kuroyanagi-keiku/)

![solution](https://raw.githubusercontent.com/Keiku/kaggle-airbnb-recruiting-new-user-bookings/master/Learning_Architecture.png)

### How to run this program.
Please edit run.R and execute run.R.
